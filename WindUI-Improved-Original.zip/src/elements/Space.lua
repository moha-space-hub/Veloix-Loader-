local Creator = require("../modules/Creator")
local New = Creator.New

local Element = {}

function Element:New(Config)
	local Size = 12
	if typeof(Config) == "number" then
		Size = Config
	elseif typeof(Config) == "table" then
		Size = Config.Size or Config.Height or Config.Space or 12
		if Config.Columns then
			Size = Size * (Config.Columns or 1)
		end
	end
	Size = math.max(0, tonumber(Size) or 12)

	local ParentType = Config and Config.ParentType
	local isHorizontal = ParentType and table.find({ "Group", "HStack" }, ParentType)

	local MainSpace = New("Frame", {
		Parent = Config and Config.Parent or nil,
		Size = isHorizontal and UDim2.new(0, Size, 0, 0) or UDim2.new(1, 0, 0, Size),
		BackgroundTransparency = 1,
		BorderSizePixel = 0,
	})

	return "Space", {
		__type = "Space",
		ElementFrame = MainSpace,
		SetSize = function(self, newSize)
			newSize = math.max(0, tonumber(newSize) or 12)
			if isHorizontal then
				MainSpace.Size = UDim2.new(0, newSize, 0, 0)
			else
				MainSpace.Size = UDim2.new(1, 0, 0, newSize)
			end
		end,
	}
end

return Element
