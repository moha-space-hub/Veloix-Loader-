local Creator = require("../modules/Creator")
local New = Creator.New
local Tween = Creator.Tween

local Element = {}

local function FetchInvite(code)
	local Request = http_request or (syn and syn.request) or request or http and http.request
	if not Request or not code or code == "" then
		return nil
	end
	local ok, result = pcall(function()
		local res = Request({
			Url = "https://discord.com/api/v10/invites/" .. tostring(code) .. "?with_counts=true&with_expiration=true",
			Method = "GET",
			Headers = {
				["Content-Type"] = "application/json",
				["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
			},
		})
		if res and (res.Body or res.body) then
			local HttpService = game:GetService("HttpService")
			return HttpService:JSONDecode(res.Body or res.body)
		end
		return nil
	end)
	if ok and result and result.guild then
		local guild = result.guild
		local iconUrl = nil
		if guild.icon then
			iconUrl = "https://cdn.discordapp.com/icons/" .. guild.id .. "/" .. guild.icon .. ".png?size=128"
		end
		local bannerUrl = nil
		if guild.banner then
			bannerUrl = "https://cdn.discordapp.com/banners/" .. guild.id .. "/" .. guild.banner .. ".png?size=512"
		end
		return {
			Name = guild.name,
			Icon = iconUrl,
			Banner = bannerUrl,
			Online = result.approximate_presence_count or 0,
			Members = result.approximate_member_count or 0,
			Description = guild.description or "",
			Id = guild.id,
		}
	end
	return nil
end

function Element:New(Config)
	Config = Config or {}
	local Invite = Config.Invite or Config.Code or ""
	local Data = {
		Name = Config.Name or "Discord Server",
		Icon = Config.Icon,
		Banner = Config.Banner,
		Online = Config.Online or 0,
		Members = Config.Members or 0,
		Description = Config.Description or Config.Desc or "",
		Created = Config.Created or "",
		ButtonText = Config.ButtonText or "Go to Server",
	}

	local UICorner = Config.Window and Config.Window.ElementConfig and Config.Window.ElementConfig.UICorner or 16
	local UIPadding = Config.Window and Config.Window.ElementConfig and Config.Window.ElementConfig.UIPadding or 12

	local Card = New("Frame", {
		Name = "DiscordCard",
		Parent = Config.Parent,
		Size = UDim2.new(1, 0, 0, 0),
		AutomaticSize = Enum.AutomaticSize.Y,
		BackgroundTransparency = 1,
		ClipsDescendants = true,
	})

	local Main, MainTable = Creator.NewRoundFrame(UICorner, "Squircle", {
		Size = UDim2.new(1, 0, 0, 0),
		AutomaticSize = Enum.AutomaticSize.Y,
		ThemeTag = {
			ImageColor3 = "ElementBackground",
			ImageTransparency = "ElementBackgroundTransparency",
		},
		Parent = Card,
	}, {
		New("UIListLayout", {
			FillDirection = Enum.FillDirection.Vertical,
			SortOrder = Enum.SortOrder.LayoutOrder,
			Padding = UDim.new(0, 0),
		}),
	}, false, true)

	local BannerFrame = New("Frame", {
		Name = "Banner",
		Size = UDim2.new(1, 0, 0, 64),
		BackgroundColor3 = Color3.fromRGB(88, 101, 242),
		BorderSizePixel = 0,
		LayoutOrder = 1,
		Parent = Main,
		ClipsDescendants = true,
	}, {
		New("UICorner", {
			CornerRadius = UDim.new(0, UICorner),
		}),
		New("Frame", {
			Size = UDim2.new(1, 0, 0, UICorner + 2),
			Position = UDim2.new(0, 0, 1, -(UICorner + 2)),
			BackgroundColor3 = Color3.fromRGB(88, 101, 242),
			BorderSizePixel = 0,
		}),
	})

	local BannerImage
	if Data.Banner then
		BannerImage = Creator.Image(Data.Banner, Data.Name .. "_banner", 0, Config.Window and Config.Window.Folder, "Discord", false)
		if BannerImage then
			BannerImage.Parent = BannerFrame
			BannerImage.Size = UDim2.new(1, 0, 1, 0)
			BannerImage.ScaleType = Enum.ScaleType.Crop
		end
	end

	local Body = New("Frame", {
		Name = "Body",
		Size = UDim2.new(1, 0, 0, 0),
		AutomaticSize = Enum.AutomaticSize.Y,
		BackgroundTransparency = 1,
		LayoutOrder = 2,
		Parent = Main,
	}, {
		New("UIPadding", {
			PaddingTop = UDim.new(0, 12),
			PaddingBottom = UDim.new(0, UIPadding),
			PaddingLeft = UDim.new(0, UIPadding),
			PaddingRight = UDim.new(0, UIPadding),
		}),
		New("UIListLayout", {
			FillDirection = Enum.FillDirection.Vertical,
			SortOrder = Enum.SortOrder.LayoutOrder,
			Padding = UDim.new(0, 10),
		}),
	})

	local TopRow = New("Frame", {
		Size = UDim2.new(1, 0, 0, 58),
		BackgroundTransparency = 1,
		LayoutOrder = 1,
		Parent = Body,
	})

	local IconHolder = Creator.NewRoundFrame(14, "Squircle", {
		Size = UDim2.new(0, 56, 0, 56),
		ThemeTag = {
			ImageColor3 = "ElementBackground",
		},
		Parent = TopRow,
	}, nil, false, true)

	local IconImage
	if Data.Icon then
		IconImage = Creator.Image(Data.Icon, Data.Name .. "_icon", 12, Config.Window and Config.Window.Folder, "Discord", false)
		if IconImage then
			IconImage.Parent = IconHolder
			IconImage.Size = UDim2.new(1, 0, 1, 0)
			IconImage.ScaleType = Enum.ScaleType.Crop
		end
	else
		New("TextLabel", {
			Size = UDim2.new(1, 0, 1, 0),
			BackgroundTransparency = 1,
			Text = string.sub(Data.Name, 1, 1):upper(),
			TextColor3 = Color3.fromRGB(255, 255, 255),
			TextSize = 22,
			FontFace = Font.new(Creator.Font, Enum.FontWeight.Bold),
			Parent = IconHolder,
		})
	end

	local NameLabel = New("TextLabel", {
		Size = UDim2.new(1, -68, 0, 22),
		Position = UDim2.new(0, 66, 0, 6),
		BackgroundTransparency = 1,
		Text = Data.Name,
		ThemeTag = {
			TextColor3 = "Text",
		},
		TextSize = 16,
		FontFace = Font.new(Creator.Font, Enum.FontWeight.SemiBold),
		TextXAlignment = Enum.TextXAlignment.Left,
		TextTruncate = Enum.TextTruncate.AtEnd,
		Parent = TopRow,
	})

	local StatsRow = New("Frame", {
		Size = UDim2.new(1, -68, 0, 18),
		Position = UDim2.new(0, 66, 0, 32),
		BackgroundTransparency = 1,
		Parent = TopRow,
	}, {
		New("UIListLayout", {
			FillDirection = Enum.FillDirection.Horizontal,
			VerticalAlignment = Enum.VerticalAlignment.Center,
			Padding = UDim.new(0, 12),
			SortOrder = Enum.SortOrder.LayoutOrder,
		}),
	})

	local OnlineLabel = New("TextLabel", {
		Size = UDim2.new(0, 0, 0, 18),
		AutomaticSize = Enum.AutomaticSize.X,
		BackgroundTransparency = 1,
		Text = "● " .. tostring(Data.Online) .. " Online",
		TextColor3 = Color3.fromRGB(51, 199, 89),
		TextSize = 12,
		FontFace = Font.new(Creator.Font, Enum.FontWeight.Medium),
		LayoutOrder = 1,
		Parent = StatsRow,
	})

	local MembersLabel = New("TextLabel", {
		Size = UDim2.new(0, 0, 0, 18),
		AutomaticSize = Enum.AutomaticSize.X,
		BackgroundTransparency = 1,
		Text = "● " .. tostring(Data.Members) .. " Members",
		ThemeTag = {
			TextColor3 = "Placeholder",
		},
		TextSize = 12,
		FontFace = Font.new(Creator.Font, Enum.FontWeight.Medium),
		LayoutOrder = 2,
		Parent = StatsRow,
	})

	local DescLabel = New("TextLabel", {
		Size = UDim2.new(1, 0, 0, 0),
		AutomaticSize = Enum.AutomaticSize.Y,
		BackgroundTransparency = 1,
		Text = Data.Description,
		ThemeTag = {
			TextColor3 = "Placeholder",
		},
		TextSize = 13,
		FontFace = Font.new(Creator.Font, Enum.FontWeight.Regular),
		TextXAlignment = Enum.TextXAlignment.Left,
		TextWrapped = true,
		LayoutOrder = 2,
		Parent = Body,
		Visible = Data.Description ~= "",
	})

	local JoinBtn, JoinBtnTable = Creator.NewRoundFrame(10, "Squircle", {
		Size = UDim2.new(1, 0, 0, 40),
		ImageColor3 = Color3.fromRGB(35, 165, 90),
		LayoutOrder = 3,
		Parent = Body,
	}, {
		New("TextLabel", {
			Size = UDim2.new(1, 0, 1, 0),
			BackgroundTransparency = 1,
			Text = Data.ButtonText,
			TextColor3 = Color3.fromRGB(255, 255, 255),
			TextSize = 14,
			FontFace = Font.new(Creator.Font, Enum.FontWeight.SemiBold),
		}),
	}, true, true)

	local Hitbox = New("TextButton", {
		Size = UDim2.new(1, 0, 1, 0),
		BackgroundTransparency = 1,
		Text = "",
		Parent = JoinBtn,
		ZIndex = 5,
	})

	Creator.AddSignal(Hitbox.MouseEnter, function()
		Tween(JoinBtn, 0.15, { ImageColor3 = Color3.fromRGB(45, 185, 105) }):Play()
	end)
	Creator.AddSignal(Hitbox.MouseLeave, function()
		Tween(JoinBtn, 0.15, { ImageColor3 = Color3.fromRGB(35, 165, 90) }):Play()
	end)
	Creator.AddSignal(Hitbox.MouseButton1Click, function()
		local link = "https://discord.gg/" .. tostring(Invite)
		if setclipboard then
			pcall(setclipboard, link)
		end
		if Config.Callback then
			Creator.SafeCallback(Config.Callback, link)
		elseif Config.OnClick then
			Creator.SafeCallback(Config.OnClick, link)
		end
	end)

	local DiscordModule = {
		__type = "Discord",
		ElementFrame = Card,
		MainFrame = Main,
		Data = Data,
	}

	function DiscordModule:Refresh()
		if Invite == "" then
			return
		end
		task.spawn(function()
			local live = FetchInvite(Invite)
			if not live then
				return
			end
			Data.Name = live.Name or Data.Name
			Data.Online = live.Online or Data.Online
			Data.Members = live.Members or Data.Members
			Data.Description = live.Description ~= "" and live.Description or Data.Description
			NameLabel.Text = Data.Name
			OnlineLabel.Text = "● " .. tostring(Data.Online) .. " Online"
			MembersLabel.Text = "● " .. tostring(Data.Members) .. " Members"
			if Data.Description ~= "" then
				DescLabel.Text = Data.Description
				DescLabel.Visible = true
			end
			if live.Icon and not IconImage then
				IconImage = Creator.Image(live.Icon, Data.Name .. "_icon", 12, Config.Window and Config.Window.Folder, "Discord", false)
				if IconImage then
					IconImage.Parent = IconHolder
					IconImage.Size = UDim2.new(1, 0, 1, 0)
					IconImage.ScaleType = Enum.ScaleType.Crop
				end
			elseif live.Icon and IconImage then
				IconImage.Image = live.Icon
			end
			if live.Banner then
				if BannerImage then
					BannerImage.Image = live.Banner
				else
					BannerImage = Creator.Image(live.Banner, Data.Name .. "_banner", 0, Config.Window and Config.Window.Folder, "Discord", false)
					if BannerImage then
						BannerImage.Parent = BannerFrame
						BannerImage.Size = UDim2.new(1, 0, 1, 0)
						BannerImage.ScaleType = Enum.ScaleType.Crop
					end
				end
			end
		end)
	end

	if Invite ~= "" then
		task.defer(function()
			DiscordModule:Refresh()
		end)
	end

	return "Discord", DiscordModule
end

return Element
